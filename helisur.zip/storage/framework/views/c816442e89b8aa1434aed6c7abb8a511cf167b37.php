<!DOCTYPE html>
<html>
	<head>
		<title>Sistema de Gestión de Competencias de Helisur</title>
		<?php echo $__env->make("common.styles", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</head>
	<body>
		<?php echo $__env->make("common.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- JS -->
		<?php echo $__env->make("common.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</body>
</html>