<!DOCTYPE html>
<html>
	<head>
		<title>Sistema de Gestión de Competencias de Helisur</title>
		<?php echo $__env->make("common.styles", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<style type="text/css">
            .text-secondary{font-size:0.75rem}
            .no-margin>*{margin:2px 0}
            .slider {-webkit-appearance:none;width:100%;height:10px;border-radius:5px;background:#d3d3d3;outline:none;opacity:0.7;-webkit-transition:.2s;transition:opacity .2s}
            .slider:hover{opacity:1;}
            .slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:25px;height:25px;border-radius:50%;background:#0d47a1;cursor:pointer}
            .slider::-moz-range-thumb{width:32px;height:32px;border-radius:50%;background:#0d47a1;cursor:pointer}
            .p-result{margin-top:10px}
            .p-result>img{width:24px}
            .list-group-item{padding:}
		</style>
	</head>
	<body>
		<?php echo $__env->make("common.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- PAGINA -->
		<div class="container">
			<div class="row">
				<form class="col" action="<?php echo e(url('responder/guardar')); ?>" method="post">
					<h2 class="text-primary">Pregunta #<?php echo e(($encuesta->actual < 10 ? "0" : "") . $encuesta->actual); ?><br><span class="text-dark"><?php echo e($pregunta->texto); ?></span></h2>
					<p class="text-secondary"><b class="text-danger"><?php echo e($encuesta->nombre); ?></b><br><?php echo e($pregunta->grupo); ?> > <?php echo e($pregunta->concepto); ?> > <?php echo e($pregunta->categoria); ?> > <?php echo e($pregunta->subcategoria); ?></p>
					<input type="hidden" name="eid" value="<?php echo e($eid); ?>">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="pid" value="<?php echo e($pregunta->pid); ?>">
					<input type="hidden" name="ptp" value="<?php echo e($pregunta->ptp); ?>">
					<input type="hidden" name="nmp" value="<?php echo e($encuesta->actual); ?>">
					<input type="hidden" name="eva" value="<?php echo e($encuesta->eva); ?>">
					<input type="hidden" name="peva" value="<?php echo e($encuesta->peva); ?>">
					<hr>
					<ul class="list-group">
                        <?php $__currentLoopData = $evaluados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="list-group-item">
							<div class="row">
								<div class="col-3 col-md-2 col-lg-1">
									<img src="<?php echo e(url('imagen', [$evaluado->uid])); ?>" class="img-fluid">
								</div>
								<div class="col-9 col-md-4 col-lg-5 no-margin">
									<p class="text-dark"><?php echo e($evaluado->evaluado); ?></p>
									<p class="text-secondary"><?php echo e($evaluado->puesto); ?> | <?php echo e($evaluado->oficina); ?></p>
								</div>
								<div class="col-12 col-md-6 col-lg-6">
									<input type="hidden" name="ids[]" value="<?php echo e(implode('|', [$evaluado->uid, $evaluado->pid])); ?>">
									<input type="range" name="puntaje[]" min="1" max="5" value="1" step="1" class="slider">
									<p class="text-secondary p-result">
										<img src="<?php echo e(asset('images/faces/1.png')); ?>">
										<span>Totalmente en desacuerdo</span>
									</p>
								</div>
							</div>
						</li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<p class="text-right">
						<br>
						<button class="btn btn-success"><i class="fa fa-check"></i> Siguiente pregunta</button>
					</p>
				</form>
			</div>
		</div>
		<!-- JS -->
		<?php echo $__env->make("common.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<script type="text/javascript">
			var labels = ["", "Totalmente en desacuerdo", "En desacuerdo", "Ni de acuerdo ni en desacuerdo", "De acuerdo", "Totalmente de acuerdo"];
			$(".slider").val(1).on("change", function(evt) {
				var input = $(this);
				var valor = input.val();
				input.next().children("img").attr("src", "<?php echo e(asset('images/faces')); ?>/" + valor + ".png");
				input.next().children("span").html(labels[valor]);
			});
		</script>
	</body>
</html>