<!DOCTYPE html>
<html>
	<head>
		<title>Sistema de Gestión de Competencias de Helisur</title>
		<?php echo $__env->make("common.styles", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<style type="text/css">
			.no-margin>p{margin:0}
		</style>
	</head>
	<body>
		<?php echo $__env->make("common.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- PAGINA -->
		<div class="container">
			<div class="row">
				<div class="col no-margin">
					<p class="text-secondary">Bienvenido</p>
					<h2 class="text-primary"><?php echo e($entidad->des_nombre_3); ?></h2>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<hr>
				<?php if(count($pendientes) > 0): ?>
					<?php $__currentLoopData = $pendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $pendiente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div id="dv-encuesta-<?php echo e($pendiente->eid); ?>" class="card bg-light" style="display:inline-block;margin:0 0.15rem;width:18rem">
						<div class="card-body">
							<h5 class="card-title"><?php echo e($pendiente->encuesta); ?></h5>
							<h6 class="card-subtitle mb-2 text-muted">
								<?php echo e($pendiente->cant); ?> preguntas<br>
								<?php echo e($pendiente->encuestas); ?> evaluado(s)
							</h6>
							<p class="card-text text-muted">
								<?php if(strcmp($pendiente->estado,"En curso") == 0): ?>
								Progreso: <?php echo e($pendiente->prog); ?> / <?php echo e($pendiente->cant); ?>

								<?php elseif(strcmp($pendiente->estado,"Valorando") == 0): ?>
								Preguntas de valoración
								<?php elseif(strcmp($pendiente->estado,"Finalizada") == 0): ?>
								Encuesta terminada
								<?php else: ?>
								Encuesta lista para comenzar
								<?php endif; ?>
							</p>
							<?php if(strcmp($pendiente->estado,"Finalizada") == 0): ?>
							<a href="javascript:void(0)" class="btn btn-success"><i class="fa fa-smile-o"></i> Gracias por participar</a>
							<?php else: ?>
							<a href="<?php echo e(url('responder', [$pendiente->eid])); ?>" class="btn btn-primary"><?php echo e($pendiente->prog == 0 ? "Iniciar" : "Continuar"); ?></a>
							<?php endif; ?>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<p class="text-dark">No tiene encuestas pendientes de responder</p>
				<?php endif; ?>
				</div>
			</div>
		</div>
		<!-- JS -->
		<?php echo $__env->make("common.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</script>
	</body>
</html>