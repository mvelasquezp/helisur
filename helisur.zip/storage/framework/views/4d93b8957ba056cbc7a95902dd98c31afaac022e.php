<!DOCTYPE html>
<html>
	<head>
		<title>Sistema de Gestión de Competencias de Helisur</title>
		<?php echo $__env->make("common.styles", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<style type="text/css">
            .text-secondary{font-size:0.75rem}
            .no-margin>*{margin:2px 0}
            .slider {-webkit-appearance:none;width:100%;height:10px;border-radius:5px;background:#d3d3d3;outline:none;opacity:0.7;-webkit-transition:.2s;transition:opacity .2s}
            .slider:hover{opacity:1;}
            .slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:25px;height:25px;border-radius:50%;background:#0d47a1;cursor:pointer}
            .slider::-moz-range-thumb{width:32px;height:32px;border-radius:50%;background:#0d47a1;cursor:pointer}
            .p-result{margin-top:10px}
            .p-result>img{width:24px}
            .list-group-item{padding:}
		</style>
	</head>
	<body>
		<?php echo $__env->make("common.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- PAGINA -->
		<div class="container">
			<div class="row">
				<form id="form-final" class="col" action="<?php echo e(url('responder/valorar')); ?>" method="post">
					<h2 class="text-primary">Ya casi has terminado</h2>
					<p class="text-secondary">Para culminar con la evaluación, te agradeceremos responder unas últimas preguntas</p>
					<input type="hidden" name="eid" value="<?php echo e($eid); ?>">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="eva" value="<?php echo e($encuesta->eva); ?>">
					<input type="hidden" name="peva" value="<?php echo e($encuesta->peva); ?>">
					<hr>
					<ul class="list-group">
                        <?php $__currentLoopData = $evaluados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="list-group-item">
							<div class="row">
								<div class="col-12 col-md-6 no-margin text-center">
									<img src="<?php echo e(url('imagen', [$evaluado->uid])); ?>" style="width:25%">
									<p class="text-info"><?php echo e($evaluado->evaluado); ?></p>
									<br>
									<p class="text-dark">En una escala del 1 al 10, y siendo 1 la valoración mínima y 10 la máxima, cómo calificarías a <b><?php echo e($evaluado->evaluado); ?></b></p>
									<br>
									<input type="range" name="valoracion[]" min="1" max="10" value="5" step="1" class="slider">
									<p class="p-result">Puntaje asignado: <b>5</b></p>
								</div>
								<div class="col-12 col-md-6">
									<input type="hidden" name="ids[]" value="<?php echo e(implode('|', [$evaluado->uid, $evaluado->pid])); ?>">
									<p class="text-success">Menciona tres aspectos positivos o fortalezas</p>
									<div class="form-group">
										<input type="text" name="fs1[]" class="form-control form-control-sm mandatory" placeholder="Aspecto positivo 1">
									</div>
									<div class="form-group">
										<input type="text" name="fs2[]" class="form-control form-control-sm" placeholder="Aspecto positivo 2">
									</div>
									<div class="form-group">
										<input type="text" name="fs3[]" class="form-control form-control-sm" placeholder="Aspecto positivo 3">
									</div>
									<p class="text-danger">Menciona tres aspectos a mejorar</p>
									<div class="form-group">
										<input type="text" name="db1[]" class="form-control form-control-sm mandatory" placeholder="Aspecto a mejorar 1">
									</div>
									<div class="form-group">
										<input type="text" name="db2[]" class="form-control form-control-sm" placeholder="Aspecto a mejorar 2">
									</div>
									<div class="form-group">
										<input type="text" name="db3[]" class="form-control form-control-sm" placeholder="Aspecto a mejorar 3">
									</div>
								</div>
							</div>
						</li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<p class="text-right">
						<br>
						<button class="btn btn-success"><i class="fa fa-check"></i> Finalizar encuesta</button>
					</p>
				</form>
			</div>
		</div>
		<!-- JS -->
		<?php echo $__env->make("common.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<script type="text/javascript">
			var labels = ["", "Totalmente en desacuerdo", "En desacuerdo", "Ni de acuerdo ni en desacuerdo", "De acuerdo", "Totalmente de acuerdo"];
			$(".slider").val(5).on("change", function(evt) {
				var input = $(this);
				var valor = input.val();
				input.next().children("b").html(valor);
			});
			$("#form-final").on("submit", function() {
				var finputs = $(".mandatory");
				var ready = true;
				$.each(finputs, function() {
					ready = ready && $(this).val() != "";
				});
				if(!ready) {
					alert("Debe ingresar al menos un aspecto positivo y un aspecto a mejorar para cada uno de sus evaluados.");
					event.preventDefault();
				}
			});
		</script>
	</body>
</html>