<!DOCTYPE html>
<html>
    <head>
        <title>Sistema de Gestión de Competencias de Helisur</title>
        <?php echo $__env->make("common.styles", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body>
        <?php echo $__env->make("common.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- pagina -->
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1 class="text-primary"><?php echo e($encuesta->nombre); ?></h1>
                    <p class="text-dark">Gracias por participar en el proceso de evaluación de competencias.</p>
                    <p class="text-dark">En esta encuesta evaluarás a las siguientes personas:</p>
                    <ul class="list-group">
                        <?php $__currentLoopData = $evaluados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item list-group-item-action flex-column align-items-start list-group-item">
                            <div class="row">
                                <div class="col-4 col-md-2 col-lg-1">
                                    <img src="<?php echo e(url('imagen', [$evaluado->uid])); ?>" class="img-fluid">
                                </div>
                                <div class="col-8 col-md-10 col-lg-11">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1 text-success"><?php echo e($evaluado->evaluado); ?></h5>
                                    </div>
                                    <p class="mb-1"><?php echo e($evaluado->puesto); ?></p>
                                    <small class="text-muted"><?php echo e($evaluado->oficina); ?></small>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <br>
                    <p class="text-dark">Recuerda que no es necesario responder todas las preguntas de una sola vez. Si lo deseas, puedes cerrar esta ventana en cualquier momento y, la próxima vez que entres, podrás continuar con la encuesta en donde te quedaste.</p>
                    <p class="text-dark">Para comenzar a evaluar, utiliza el botón "Comenzar con la evaluación" que se muestra a continuación.</p>
                    <p class="text-right">
                        <a href="<?php echo e(url('responder/comenzar', [$eid])); ?>" class="btn btn-lg btn-success"><i class="fa fa-play"></i> Comenzar con la evaluación</a>
                    </p>
                    <p class="text-secondary text-right">Ten presente que el plazo para responder esta encuesta vence el <b><?php echo e($encuesta->plazo); ?></b></p>
                </div>
            </div>
        </div>
        <!-- JS -->
        <?php echo $__env->make("common.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>