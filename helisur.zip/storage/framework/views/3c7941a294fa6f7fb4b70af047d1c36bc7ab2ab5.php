<!DOCTYPE html>
<html>
	<head>
		<title>Sistema de Gestión de Competencias de Helisur</title>
		<?php echo $__env->make("common.styles", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/datepicker.min.css')); ?>">
	</head>
	<body>
		<?php echo $__env->make("common.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- PAGINA -->
		<div class="container">
			<div class="row">
				<div class="col">
					<ul class="nav nav-tabs" id="myTab" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" id="grupos-tab" data-toggle="tab" href="#grupos" role="tab" aria-controls="grupos" aria-selected="true">Grupos</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" id="conceptos-tab" data-toggle="tab" href="#conceptos" role="tab" aria-controls="conceptos" aria-selected="false">Conceptos</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" id="categorias-tab" data-toggle="tab" href="#categorias" role="tab" aria-controls="categorias" aria-selected="false">Categorías</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" id="subcategorias-tab" data-toggle="tab" href="#subcategorias" role="tab" aria-controls="subcategorias" aria-selected="false">Subcategorías</a>
						</li>
					</ul>
					<div class="tab-content" id="myTabContent">
						<div class="tab-pane fade show active" id="grupos" role="tabpanel" aria-labelledby="grupos-tab">
							<table class="table table-hover">
								<thead>
									<tr>
										<th width="5%">#</th>
										<th>Grupo</th>
										<th></th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td>
											<span class="btn btn-primary btn-xs"><?php echo e($idx + 1); ?></span>
										</td>
										<td><?php echo e($grupo->nombre); ?></td>
										<td>
											<?php if(strcmp($grupo->estado, "S") == 0): ?>
											<a href="#" class="btn btn-danger btn-xs btn-del-grupo" data-gid="<?php echo e($grupo->id); ?>"><i class="fa fa-remove"></i> Retirar</a>
											<?php else: ?>
											<a href="#" class="btn btn-primary btn-xs btn-act-grupo" data-gid="<?php echo e($grupo->id); ?>"><i class="fa fa-refresh"></i> Activar</a>
											<?php endif; ?>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td></td>
										<td><input type="text" class="form-control form-control-sm" id="ins-grupo" placeholder="Ingrese nombre para crear un nuevo grupo"></td>
										<td><a href="#" class="btn btn-success btn-xs" id="btn-ins-grupo"><i class="fa fa-plus"></i> Crear</a></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="tab-pane fade" id="conceptos" role="tabpanel" aria-labelledby="conceptos-tab">
							<table class="table table-hover">
								<thead>
									<tr>
										<th width="5%">#</th>
										<th>Concepto</th>
										<th></th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $concepto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td>
											<span class="btn btn-primary btn-xs"><?php echo e($idx + 1); ?></span>
										</td>
										<td><?php echo e($concepto->nombre); ?></td>
										<td>
											<?php if(strcmp($concepto->estado, "S") == 0): ?>
											<a href="#" class="btn btn-danger btn-xs btn-del-concepto" data-nid="<?php echo e($concepto->id); ?>"><i class="fa fa-remove"></i> Retirar</a>
											<?php else: ?>
											<a href="#" class="btn btn-primary btn-xs btn-act-concepto" data-nid="<?php echo e($concepto->id); ?>"><i class="fa fa-refresh"></i> Activar</a>
											<?php endif; ?>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td></td>
										<td><input type="text" class="form-control form-control-sm" id="ins-concepto" placeholder="Ingrese nombre para crear un nuevo concepto"></td>
										<td><a href="#" class="btn btn-success btn-xs" id="btn-ins-concepto"><i class="fa fa-plus"></i> Crear</a></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="tab-pane fade" id="categorias" role="tabpanel" aria-labelledby="categorias-tab">
							<table class="table table-hover">
								<thead>
									<tr>
										<th width="5%">#</th>
										<th>Categoría</th>
										<th></th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td>
											<span class="btn btn-primary btn-xs"><?php echo e($idx + 1); ?></span>
										</td>
										<td><?php echo e($categoria->nombre); ?></td>
										<td>
											<?php if(strcmp($categoria->estado, "S") == 0): ?>
											<a href="#" class="btn btn-danger btn-xs btn-del-categoria" data-cid="<?php echo e($categoria->id); ?>"><i class="fa fa-remove"></i> Retirar</a>
											<?php else: ?>
											<a href="#" class="btn btn-primary btn-xs btn-act-categoria" data-cid="<?php echo e($categoria->id); ?>"><i class="fa fa-refresh"></i> Activar</a>
											<?php endif; ?>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td></td>
										<td><input type="text" class="form-control form-control-sm" id="ins-categoria" placeholder="Ingrese nombre para crear una nueva categoría"></td>
										<td><a href="#" class="btn btn-success btn-xs" id="btn-ins-categoria"><i class="fa fa-plus"></i> Crear</a></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="tab-pane fade" id="subcategorias" role="tabpanel" aria-labelledby="subcategorias-tab">
							<table class="table table-hover">
								<thead>
									<tr>
										<th width="5%">#</th>
										<th width="15%">Categoría</th>
										<th>Subcategoría</th>
										<th width="15%"></th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td>
											<span class="btn btn-primary btn-xs"><?php echo e($idx + 1); ?></span>
										</td>
										<td><?php echo e($subcategoria->categoria); ?></td>
										<td><?php echo e($subcategoria->nombre); ?></td>
										<td>
											<?php if(strcmp($subcategoria->estado, "S") == 0): ?>
											<a href="#" class="btn btn-danger btn-xs btn-del-subcategoria" data-sid="<?php echo e($subcategoria->id); ?>" data-cid="<?php echo e($subcategoria->gato); ?>"><i class="fa fa-remove"></i> Retirar</a>
											<?php else: ?>
											<a href="#" class="btn btn-primary btn-xs btn-act-subcategoria" data-sid="<?php echo e($subcategoria->id); ?>" data-cid="<?php echo e($subcategoria->gato); ?>"><i class="fa fa-refresh"></i> Activar</a>
											<?php endif; ?>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td></td>
										<td>
											<select class="form-control form-control-sm" id="ins-subcategoria-cat">
												<option value="0" selected disabled>Seleccione</option>
												<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if(strcmp($categoria->estado,"S") == 0): ?>
												<option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</td>
										<td><input type="text" class="form-control form-control-sm" id="ins-subcategoria" placeholder="Ingrese nombre para crear una nueva subcategoría"></td>
										<td><a href="#" class="btn btn-success btn-xs" id="btn-ins-subcategoria"><i class="fa fa-plus"></i> Crear</a></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- JS -->
		<?php echo $__env->make("common.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<script type="text/javascript">
			function RegistraGrupo() {
				var nombre = document.getElementById("ins-grupo").value;
				var p = {_token:"<?php echo e(csrf_token()); ?>", nom: nombre};
				if(nombre != "") {
					$("#btn-ins-grupo").hide();
					$.post("<?php echo e(url('preguntas/ajax/ins-grupo')); ?>", p, function(response) {
						if(response.success) {
							document.getElementById("ins-grupo").value = "";
							location.reload();
						}
						else {
							$("#btn-ins-grupo").show();
							alert(response.msg);
						}
					}, "json").error(function(error) {
						$("#btn-ins-grupo").show();
					});
				}
				else alert("Ingrese correctamente el nombre");
			}
			function RegistraConcepto() {
				var nombre = document.getElementById("ins-concepto").value;
				var p = {_token:"<?php echo e(csrf_token()); ?>", nom: nombre};
				if(nombre != "") {
					$("#btn-ins-concepto").hide();
					$.post("<?php echo e(url('preguntas/ajax/ins-concepto')); ?>", p, function(response) {
						if(response.success) {
							document.getElementById("ins-concepto").value = "";
							location.reload();
						}
						else {
							$("#btn-ins-concepto").show();
							alert(response.msg);
						}
					}, "json").error(function(error) {
						$("#btn-ins-concepto").show();
					});
				}
				else alert("Ingrese correctamente el nombre");
			}
			function RegistraCategoria() {
				var nombre = document.getElementById("ins-categoria").value;
				var p = {_token:"<?php echo e(csrf_token()); ?>", nom: nombre};
				if(nombre != "") {
					$("#btn-ins-categoria").hide();
					$.post("<?php echo e(url('preguntas/ajax/ins-categoria')); ?>", p, function(response) {
						if(response.success) {
							document.getElementById("ins-categoria").value = "";
							location.reload();
						}
						else {
							$("#btn-ins-categoria").show();
							alert(response.msg);
						}
					}, "json").error(function(error) {
						$("#btn-ins-categoria").show();
					});
				}
				else alert("Ingrese correctamente el nombre");
			}
			function RegistraSubcategoria() {
				var nombre = document.getElementById("ins-subcategoria").value;
				var categoria = document.getElementById("ins-subcategoria-cat").value;
				var p = {_token:"<?php echo e(csrf_token()); ?>", nom: nombre, cat: categoria};
				if(nombre != "" && categoria != 0) {
					$("#btn-ins-subcategoria").hide();
					$.post("<?php echo e(url('preguntas/ajax/ins-subcategoria')); ?>", p, function(response) {
						if(response.success) {
							document.getElementById("ins-subcategoria").value = "";
							location.reload();
						}
						else {
							$("#btn-ins-subcategoria").show();
							alert(response.msg);
						}
					}, "json").error(function(error) {
						$("#btn-ins-subcategoria").show();
					});
				}
				else alert("Ingrese correctamente la categoría y el nombre");
			}
			function EliminarGrupo(event) {
				event.preventDefault();
				if(window.confirm("¿Seguro que desea eliminar al grupo?")) {
					var a = $(this);
					var p = { _token:"<?php echo e(csrf_token()); ?>",gid:a.data("gid") };
					$.post("<?php echo e(url('preguntas/ajax/del-grupo')); ?>", p, function(response) {
						if(response.success) {
							alert("Se retiró al grupo");
							location.reload();
						}
					}, "json");
				}
			}
			function EliminarConcepto(event) {
				event.preventDefault();
				if(window.confirm("¿Seguro que desea eliminar al concepto?")) {
					var a = $(this);
					var p = { _token:"<?php echo e(csrf_token()); ?>",nid:a.data("nid") };
					$.post("<?php echo e(url('preguntas/ajax/del-concepto')); ?>", p, function(response) {
						if(response.success) {
							alert("Se retiró al concepto");
							location.reload();
						}
					}, "json");
				}
			}
			function EliminarCategoria(event) {
				event.preventDefault();
				if(window.confirm("¿Seguro que desea eliminar la categoria?")) {
					var a = $(this);
					var p = { _token:"<?php echo e(csrf_token()); ?>",cid:a.data("cid") };
					$.post("<?php echo e(url('preguntas/ajax/del-categoria')); ?>", p, function(response) {
						if(response.success) {
							alert("Se retiró la categoria");
							location.reload();
						}
					}, "json");
				}
			}
			function EliminarSubcategoria(event) {
				event.preventDefault();
				if(window.confirm("¿Seguro que desea eliminar la subcategoria?")) {
					var a = $(this);
					var p = { _token:"<?php echo e(csrf_token()); ?>",sid:a.data("sid"),cid:a.data("cid") };
					$.post("<?php echo e(url('preguntas/ajax/del-subcategoria')); ?>", p, function(response) {
						if(response.success) {
							alert("Se retiró la subcategoria");
							location.reload();
						}
					}, "json");
				}
			}
			$("#btn-ins-grupo").on("click", RegistraGrupo);
			$("#btn-ins-concepto").on("click", RegistraConcepto);
			$("#btn-ins-categoria").on("click", RegistraCategoria);
			$("#btn-ins-subcategoria").on("click", RegistraSubcategoria);
			$(".btn-del-grupo").on("click", EliminarGrupo);
			$(".btn-del-concepto").on("click", EliminarConcepto);
			$(".btn-del-categoria").on("click", EliminarCategoria);
			$(".btn-del-subcategoria").on("click", EliminarSubcategoria);
		</script>
	</body>
</html>