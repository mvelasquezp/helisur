<!DOCTYPE html>
<html>
	<head>
		<title>Sistema de Gestión de Competencias de Helisur</title>
		<?php echo $__env->make("common.styles", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/datepicker.min.css')); ?>">
	</head>
	<body>
		<?php echo $__env->make("common.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- PAGINA -->
		<div class="container">
			<div class="row">
				<div class="col">
					<table class="table table-hover table-striped">
						<thead>
							<tr>
								<th width="5%">#</th>
								<th width="10%">Grupo</th>
								<th width="10%">Concepto</th>
								<th width="10%">Categoría</th>
								<th width="10%">Subcategoría</th>
								<th>Pregunta</th>
								<th width="5%"></th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td>
									<span class="btn btn-primary btn-xs"><?php echo e($idx + 1); ?></span>
								</td>
								<td><?php echo e($pregunta->grupo); ?></td>
								<td><?php echo e($pregunta->concepto); ?></td>
								<td><?php echo e($pregunta->categoria); ?></td>
								<td><?php echo e($pregunta->subcategoria); ?></td>
								<td><?php echo e($pregunta->texto); ?></td>
								<td><a href="#" class="btn btn-danger btn-xs btn-retira" data-id="<?php echo e($pregunta->id); ?>"><i class="fa fa-remove"></i> Retirar</a></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td></td>
								<td>
									<select id="ins-grupo" class="form-control form-control-sm">
										<option value="0" selected disabled>Seleccione</option>
										<?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($grupo->id); ?>"><?php echo e($grupo->nombre); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</td>
								<td>
									<select id="ins-concepto" class="form-control form-control-sm">
										<option value="0" selected disabled>Seleccione</option>
										<?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concepto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($concepto->id); ?>"><?php echo e($concepto->nombre); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</td>
								<td>
									<select id="ins-categoria" class="form-control form-control-sm">
										<option value="0" selected disabled>Seleccione</option>
										<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</td>
								<td>
									<select id="ins-subcategoria" class="form-control form-control-sm">
										<option value="0" selected disabled>Seleccione</option>
										<?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($subcategoria->id); ?>"><?php echo e($subcategoria->nombre); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</td>
								<td><input type="text" class="form-control form-control-sm" id="ins-pregunta" placeholder="Ingrese texto de la nueva pregunta a crear"></td>
								<td><a href="#" class="btn btn-success btn-xs" id="btn-ins-pregunta"><i class="fa fa-plus"></i> Crear</a></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<!-- JS -->
		<?php echo $__env->make("common.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<script type="text/javascript">
			function GuardarPregunta() {
				$("#btn-ins-pregunta").hide();
				var grupo = document.getElementById("ins-grupo").value;
				var concepto = document.getElementById("ins-concepto").value;
				var categoria = document.getElementById("ins-categoria").value;
				var subcategoria = document.getElementById("ins-subcategoria").value;
				var pregunta = document.getElementById("ins-pregunta").value;
				var p = { _token: "<?php echo e(csrf_token()); ?>", grp: grupo, cnc: concepto, cat: categoria,sct: subcategoria,prg: pregunta };
				$.post("<?php echo e(url('preguntas/ajax/ins-pregunta')); ?>", p, function(response) {
					if(response.success) {
						document.getElementById("ins-pregunta").value = "";
						location.reload();
					}
					else {
						alert(response.msg);
						$("#btn-ins-pregunta").hide();
					}
				}, "json");
			}
			$("#btn-ins-pregunta").on("click", GuardarPregunta);
			$("#ins-categoria").on("change", function() {
				var cat = $(this).val();
				var p = { _token:"<?php echo e(csrf_token()); ?>",cat:cat };
				$.post("<?php echo e(url('preguntas/ajax/ls-subcategorias')); ?>", p, function(response) {
					if(response.success) {
						$("#ins-subcategoria").empty();
						var scats = response.data;
						for(var i in scats) {
							var scat = scats[i];
							$("#ins-subcategoria").append(
								$("<option/>").val(scat.value).html(scat.text)
							);
						}
					}
					else alert(response.msg);
				}, "json");
			});
			$(".btn-retira").on("click", function(event) {
				event.preventDefault();
				var p = {
					_token: "<?php echo e(csrf_token()); ?>",
					pid: $(this).data("id")
				};
				$.post("<?php echo e(url('preguntas/ajax/del-pregunta')); ?>", p, function(response) {
					if(response.success) location.reload();
					else alert(response.msg);
				}, "json");
			});
		</script>
	</body>
</html>