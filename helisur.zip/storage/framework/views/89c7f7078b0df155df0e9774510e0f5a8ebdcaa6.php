<?php echo '<?xml version="1.0" encoding="UTF-8"?>';?>
<root>
	<message>
		<saludo><?php echo $saludo; ?></saludo>
		<mensaje><?php echo $mensaje; ?></mensaje>
		<enlace><?php echo $enlace; ?></enlace>
	</message>
</root>