<?php echo '<?xml version="1.0" encoding="UTF-8"?>';?>
<root>
	<message>
		<saludo>{!! $saludo !!}</saludo>
		<mensaje>{!! $mensaje !!}</mensaje>
		<enlace>{!! $enlace !!}</enlace>
	</message>
</root>