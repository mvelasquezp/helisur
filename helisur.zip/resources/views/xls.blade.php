<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
	<body>
		<table>
			<tr>
				<th>cabecera 0</th>
				<th>cabecera 1</th>
				<th>cabecera 2</th>
			</tr>
			<tr>
				<td>cuerpo 00</td>
				<td>cuerpo 01</td>
				<td>cuerpo 02</td>
			</tr>
			<tr>
				<td>cuerpo 10</td>
				<td>cuerpo 11</td>
				<td>cuerpo 12</td>
			</tr>
			<tr>
				<td>cuerpo 20</td>
				<td>cuerpo 21</td>
				<td>cuerpo 22</td>
			</tr>
			<tr>
				<td>cuerpo 30</td>
				<td>cuerpo 31</td>
				<td>cuerpo 32</td>
			</tr>
		</table>
	</body>
</html>